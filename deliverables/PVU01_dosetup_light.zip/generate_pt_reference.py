#!/usr/bin/env python3
"""Generate a model-based R410A saturation reference, not approved PLC firmware."""
import bisect
import csv
import hashlib
import json
import math
from pathlib import Path

import CoolProp
from CoolProp.CoolProp import PropsSI, get_global_param_string


ROOT = Path(__file__).resolve().parent
FLUID = "HEOS::R410A"
LOW_KPA = 100.0
HIGH_KPA = 4800.0
STEP_KPA = 10.0


def saturation(p_kpa):
    return [PropsSI("T", "P", p_kpa * 1000, "Q", q, FLUID) - 273.15
            for q in [0, 1]]  # Bubble, dew; P passed to CoolProp in Pa.


def interpolate(rows, p_kpa, col):
    if not math.isfinite(p_kpa) or not rows[0][0] <= p_kpa <= rows[-1][0]:
        raise ValueError("P outside reference range; no extrapolation")
    pressures = [r[0] for r in rows]
    i = min(max(bisect.bisect_right(pressures, p_kpa) - 1, 0), len(rows) - 2)
    a, b = rows[i], rows[i + 1]
    return a[col] + (b[col] - a[col]) * (p_kpa - a[0]) / (b[0] - a[0])


def main():
    out = ROOT / "prepared"
    out.mkdir(exist_ok=True)
    count = round((HIGH_KPA - LOW_KPA) / STEP_KPA) + 1
    # Test the rounded values which will actually be exported, not hidden precision.
    rows = []
    for i in range(count):
        p = LOW_KPA + i * STEP_KPA
        bubble, dew = saturation(p)
        rows.append([p, round(bubble, 6), round(dew, 6)])
    if not all(math.isfinite(v) for row in rows for v in row):
        raise RuntimeError("Non-finite saturation data")
    if not all(row[2] >= row[1] for row in rows):
        raise RuntimeError("Dew temperature below bubble temperature")
    if not all(rows[i + 1][col] > rows[i][col]
               for i in range(len(rows) - 1) for col in [0, 1, 2]):
        raise RuntimeError("Reference pressure/temperature is not strictly increasing")

    errors = {"bubble_K": 0.0, "dew_K": 0.0}
    samples = 0
    for a, b in zip(rows, rows[1:]):
        for fraction in [0.25, 0.5, 0.75]:
            p = a[0] + fraction * (b[0] - a[0])
            actual = saturation(p)
            for col, key in [(1, "bubble_K"), (2, "dew_K")]:
                errors[key] = max(errors[key], abs(interpolate(rows, p, col) - actual[col - 1]))
            samples += 1
    # This is a numerical interpolation criterion, not a refrigeration safety setpoint.
    if max(errors.values()) > 0.05:
        raise RuntimeError(f"Interpolation error exceeds 0.05 K: {errors}")

    rejected = []
    for p in [LOW_KPA - 1, HIGH_KPA + 1, math.nan, math.inf]:
        try:
            interpolate(rows, p, 2)
        except ValueError:
            rejected.append(str(p))
        else:
            raise RuntimeError("Lookup unexpectedly extrapolated")

    critical_kpa = PropsSI("Pcrit", FLUID) / 1000
    if HIGH_KPA >= critical_kpa:
        raise RuntimeError("Reference includes the critical pressure")
    try:
        saturation(critical_kpa + 100)
    except (ValueError, RuntimeError):
        supercritical_rejected = True
    else:
        raise RuntimeError("Model unexpectedly returned saturation above critical pressure")

    table = out / "R410A_PT_reference.csv"
    with table.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["P_kPa_abs", "T_BUBBLE_C", "T_DEW_C"])
        for p, bubble, dew in rows:
            w.writerow([f"{p:.1f}", f"{bubble:.6f}", f"{dew:.6f}"])
    result = {
        "status": "REFERENCE_ONLY_NOT_COMMISSIONED",
        "model": FLUID,
        "model_description": "CoolProp HEOS R410A predefined pseudo-pure fluid; not a REFPROP calculation",
        "CoolProp_version": CoolProp.__version__,
        "CoolProp_git_revision": get_global_param_string("gitrevision"),
        "pressure_unit_in_CSV": "kPa absolute",
        "temperature_unit_in_CSV": "degree Celsius",
        "Q0": "bubble for SC; saturation liquid",
        "Q1": "dew for SH; saturation vapor",
        "rows": len(rows), "range_kPa_abs": [LOW_KPA, HIGH_KPA],
        "step_kPa": STEP_KPA, "critical_pressure_kPa_abs": critical_kpa,
        "interpolation": "piecewise linear; refuse out-of-range and non-finite input",
        "checked_off_grid_pressures": samples,
        "observed_max_interpolation_error_K": errors,
        "numerical_error_limit_K": 0.05,
        "boundary_inputs_rejected": rejected,
        "above_critical_saturation_rejected": supercritical_rejected,
        "table_SHA256": hashlib.sha256(table.read_bytes()).hexdigest(),
        "checks_passed": ["finite values", "strict monotonicity", "dew >= bubble",
                          "off-grid interpolation error", "lookup input bounds",
                          "critical pressure exclusion", "supercritical saturation rejection"],
        "limitations": [
            "Numerical agreement with the same model is not independent physical validation.",
            "Not verified against a Danfoss R410A saturation table or REFPROP.",
            "Not automatically imported into SMLogix; native LOOKUP capacity/types need verification.",
            "Pressure range is a calculation range, not an approved equipment operating envelope.",
            "4-20 mA sensor scaling still needs sensor and AIN verification; P_ATM is site dependent."]
    }
    (out / "R410A_PT_validation.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"PT reference: {len(rows)} rows; {samples} off-grid pressure checks; "
          f"max error {max(errors.values()):.6f} K; 7 checks passed; not commissioned")


if __name__ == "__main__":
    main()
