#!/usr/bin/env python3
"""Read-only package checks; this is not a SMLogix compiler or PLC simulator."""
import argparse
import collections
import csv
import hashlib
import html
import json
from pathlib import Path
import shutil
import sys
import xml.etree.ElementTree as ET


def text(value):
    import re
    return html.unescape(re.sub(r"<[^>]*>", " ", value or "")).strip()


def inspect(source):
    problems = []
    result = {"scope": "file structure and embedded hardware metadata only",
              "source": str(source), "files": {}, "problems": problems}
    for p in sorted(source.iterdir()):
        if p.is_file():
            result["files"][p.name] = {
                "bytes": p.stat().st_size,
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}

    tables = {}
    for name in ["PVU01_ETS6_25_COMP_FBD_blocks.csv",
                 "PVU01_ETS6_25_COMP_FBD_connections.csv",
                 "PVU01_ETS6_25_COMP_MRL_IO.csv"]:
        with (source / name).open(encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f, delimiter=";")
            rows = list(reader)
            for line, row in enumerate(rows, 2):
                if None in row or any(v is None for v in row.values()):
                    problems.append(f"{name}:{line}: inconsistent column count")
            tables[name] = rows
            result["files"][name]["rows"] = len(rows)

    blocks = tables["PVU01_ETS6_25_COMP_FBD_blocks.csv"]
    connections = tables["PVU01_ETS6_25_COMP_FBD_connections.csv"]
    keys = [(b["Лист"], b["ID"]) for b in blocks]
    duplicates = [list(k) for k, n in collections.Counter(keys).items() if n > 1]
    if duplicates:
        problems.append(f"Duplicate CSV block keys: {duplicates}")
    keyset = set(keys)
    for row in connections:
        for column in ["Откуда", "Куда"]:
            if (row["Лист"], row[column]) not in keyset:
                problems.append(f"CSV endpoint missing: {row['Лист']}:{row[column]}")

    root = ET.parse(source / "PVU01_ETS6_25_MRL_COMPRESSOR_FBD_v5.drawio").getroot()
    pages = {}
    total_edges = 0
    for diagram in root.findall("diagram"):
        name = diagram.get("name")
        if name in pages:
            problems.append(f"Duplicate diagram name: {name}")
        cells = diagram.findall(".//mxCell")
        ids = [c.get("id") for c in cells]
        duplicates = [k for k, n in collections.Counter(ids).items() if n > 1]
        if duplicates:
            problems.append(f"{name}: duplicate cell IDs {duplicates}")
        index = {c.get("id"): c for c in cells}
        edges = []
        for c in cells:
            for attr in ["source", "target", "parent"]:
                value = c.get(attr)
                if value is not None and value not in index:
                    problems.append(f"{name}:{c.get('id')}: missing {attr}={value}")
            if c.get("edge") == "1":
                edges.append([c.get("source"), c.get("target"), text(c.get("value"))])
        total_edges += len(edges)
        pages[name] = {"cells": len(cells), "edges": len(edges)}
        csv_blocks = [b for b in blocks if b["Лист"] == name]
        if csv_blocks:
            prefix = "v5_" + name + "_"
            for block in csv_blocks:
                if prefix + block["ID"] not in index:
                    problems.append(f"{name}: CSV block absent from drawio: {block['ID']}")
            expected = collections.Counter(
                (prefix + c["Откуда"], prefix + c["Куда"], c["Пин / сигнал"])
                for c in connections if c["Лист"] == name)
            actual = collections.Counter(tuple(edge) for edge in edges)
            if expected != actual:
                problems.append(f"{name}: CSV and drawio edges differ")
    result["drawio"] = {"pages": pages, "page_count": len(pages), "edge_count": total_edges}
    result["csv_coverage"] = "EEV_11..EEV_20 only; EEV_01..04,09,10 exist in drawio only"

    psl = (source / "Original_Pixel2_UNMODIFIED.psl").read_bytes()
    marker = b'{"Configuration"'
    start = psl.find(marker)
    if start < 0:
        problems.append("Embedded PSL hardware configuration JSON not found")
    else:
        obj, _ = json.JSONDecoder().raw_decode(psl[start:].decode("utf-8", errors="replace"))
        config = obj["Configuration"]["data"]
        # Whitelist hardware information; do not export the embedded application database.
        devices = [{k: d.get(k) for k in ["key", "class", "revision", "bus", "port"]}
                   for d in config.get("Devices", [])]
        resources = [{"info": r["info"], "settings": r.get("settings", {})}
                     for r in config.get("Resources", [])
                     if r.get("info", {}).get("id") in ["AIN5", "AIN6", "AIN7", "AIN8", "EVD1"]]
        result["psl_hardware"] = {"json_offset": start, "devices": devices,
                                  "selected_resources": resources,
                                  "has_MRL": any("MRL" in str(d.get("key", "")).upper()
                                                 for d in devices)}
    result["pressure_scaling_samples"] = [
        {"mA": i, "bar_g": (i - 4) * 3.125,
         "kPa_abs_at_standard_atmosphere": ((i - 4) * 3.125 + 1.01325) * 100}
        for i in [4, 12, 20]]
    result["compiler_on_PATH"] = {n: shutil.which(n) for n in ["SMLogix", "smLogix", "smlogix"]}
    result["structure_status"] = "FAIL" if problems else "PASS"
    result["compilation_status"] = "NOT_RUN"
    result["compilation_blockers"] = [
        "The v5 package contains a design specification, not an integrated SMLogix project.",
        "The only PSL is the unmodified original and its hardware configuration has no MRL.",
        "No SMLogix compiler is installed on PATH; a supported toolchain is required."]
    result["application_and_hardware_tests"] = "NOT_RUN"
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path(__file__).resolve().parent / "source")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--structure-only", action="store_true",
                        help="Return success for valid file structure; makes no build-readiness claim")
    args = parser.parse_args()
    try:
        result = inspect(args.source.resolve())
    except (OSError, ValueError, KeyError, ET.ParseError) as e:
        print(f"Validation failed: {e}", file=sys.stderr)
        return 1
    serialized = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.write_text(serialized, encoding="utf-8")
    else:
        print(serialized, end="")
    print(f"Structure: {result['structure_status']}; "
          f"{result['drawio']['page_count']} pages; {result['drawio']['edge_count']} edges; "
          f"compilation: NOT_RUN", file=sys.stderr)
    if result["problems"]:
        return 1
    return 0 if args.structure_only else 2


if __name__ == "__main__":
    sys.exit(main())
